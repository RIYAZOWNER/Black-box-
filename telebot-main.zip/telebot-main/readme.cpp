step 1 :-  pip install python-telegram-bot --upgrade
step 2 :- pkg install git
step 3 :- git clone https://github.com/Arvind144/telebot.git
step 4 :- cd telebot 
step 5 :- ls
step 6 :- python broadcast.py

for more information :- @introvert_danger
